package com.pranab.numberlistapp

data class Data(val number : String, val audioFileName : String)